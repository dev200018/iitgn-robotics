#Kshitija Anam 18110087

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

temp = pd.read_excel(r'C:\Users\anamk\OneDrive\Desktop\Semester 7\ITR\Gait_DATA.xlsx')

x = list(temp['X (cm)'])
y = list(temp['Y (cm)'])

plt.scatter(x,y)
plt.show()

l1 = 40
l2 = 35

# Inverse Kinematics 2R Planar Fixed Axis from Repo
def inverse_kinematics(x, y, l1, l2, elbow):  # elbow parameter = 1 or -1 for elbow down and up configurations
    D = (x ** 2 + y ** 2 - l1 ** 2 - l2 ** 2) / (2 * l1 * l2)
    if D>1 or D<-1:
        print("outside workspace")
    if elbow == 1:
        D = (x ** 2 + y ** 2 - l1 ** 2 - l2 ** 2) / (2 * l1 * l2)
        q2 = elbow * np.arctan2(np.sqrt(1 - D ** 2), D)  # q2 as measured from frame of link 1
        q1 = np.arctan2(y, x) - np.arctan2(l2 * np.sin(q2), l1 + l2 * np.cos(q2))
        q2 = q2 + q1  # if q2 is not measured from inertial frame then remove this line
    if elbow == -1:
        q2 = elbow * np.arctan2(np.sqrt(1 - D ** 2), D)  # q2 as measured from frame of link 1
        q1 = np.arctan2(y, x) - np.arctan2(l2 * np.sin(q2), l1 + l2 * np.cos(q2))
        q2 = q2 + q1  # if q2 is not measured from inertial frame then remove this line
    return q1, q2


# Forward Kinematics 2R Planar Fixed Axis from Repo
def forward_kinematics(q1, q2, l1, l2):
    x1 = l1 * np.cos(q1)
    y1 = l1 * np.sin(q1)
    x2 = l1 * np.cos(q1) + l2 * np.cos(q2)  # l2*np.cos(q2+q1) will be second term if q2 measured from link1
    y2 = l1 * np.sin(q1) + l2 * np.sin(q2)  # l2*np.sin(q2+q1) will be second term if q2 measured from link1
    return x1, y1, x2, y2

n = len(x)

for i in range (n):
    x_temp = x[i]
    y_temp = y[i]
    elbow = 1
    [q1,q2] = inverse_kinematics(x_temp, y_temp, l1, l2, elbow)
    [x1, y1, x2, y2] = forward_kinematics(q1, q2, l1, l2)
    print(x_temp,x2) #when x2 is outside workspace the NaN will be printed
    print(y_temp,y2)
    print()

