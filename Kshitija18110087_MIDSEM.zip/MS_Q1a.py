#Kshitija Anam 18110087

import numpy as np

def scara_invkin(x,y,z,l1,l2):
    r = (x**2+y**2-l1**2-l2**2)/(2*l1*l2)
    if r>1 or r<-1:
        print("outside workspace")
    theta2 = np.arctan2(np.sqrt(1-r**2),r)
    theta1 = np.arctan2(y,x) - np.arctan2((l2*np.sin(theta2)),(l1+l2*np.cos(theta2)))
    d3 = -z
    print("Theta1 = ", theta1, "\n Theta2 =", theta2,"\n Extension: ", d3, "\n")
    return theta1, theta2, d3

def stanford_invkin(x,y,z,l1,l2):
    phi = np.arctan2(y,x)
    r = np.sqrt(x**2 + y**2)
    s = z - l1
    t = np.sqrt(r**2 - l2**2)
    theta1 = phi - np.arctan2(l2,t)
    theta2 = np.arctan2(np.cos(theta1)*x+np.sin(theta1)*y,s)
    d3 = np.sin(theta2)*(np.cos(theta1)*x + np.sin(theta1)*y) + np.cos(theta2)*s
    print("Theta1 = ", theta1, "\n Theta2 =", theta2,"\n Extension: ", d3, "\n")
    return theta1, theta2, d3

def puma_invkin(x,y,z,l1,l2,l3):
    theta1 = np.arctan2(y,x)
    D = (x**2+y**2+(z-l1)**2-l2**2-l3**2)/(2*l2*l3)
    if D>1 or D<-1:
        print("outside workspace")
    theta3 = np.arctan2(np.sqrt(1-D**2), D)
    theta2 = np.arctan2(z-l1,np.sqrt(x**2+y**2))-np.arctan2(l3*np.sin(theta3),l2+l3*np.cos(theta3))
    print("Theta1 = ", theta1, "\n Theta2 =", theta2,"\n Theta3: ", theta3, "\n")
    return theta1, theta2, theta3


print("Enter 1 for Standford-type (RRP)")
print("Enter 2 for PUMA-type (RRR)")
print("Enter 3 for SCARA-type (RRP)")
n = int(input("Enter Robot type: "))

if n==1:
    x = float(input("x: "))
    y = float(input("y: "))
    z = float(input("z: "))

    l1 = float(input("l1: "))
    l2 = float(input("l2: "))

    [theta1,theta2,d3] = stanford_invkin(x,y,z,l1,l2)
    dx = -l2*np.sin(theta1) + d3*np.sin(theta2)*np.cos(theta1)
    dy = l2*np.cos(theta1) + d3*np.sin(theta2)*np.sin(theta1)
    dz = d3*np.cos(theta2) + l1
    print(dx,dy,dz)

if n==2:
    x = float(input("x: "))
    y = float(input("y: "))
    z = float(input("z: "))

    l1 = float(input("l1: "))
    l2 = float(input("l2: "))
    l3 = float(input("l3: "))

    [theta1,theta2,theta3] = puma_invkin(x,y,z,l1,l2,l3)
    dx = l2*np.cos(theta1)*np.cos(theta2) + l3*np.cos(theta1)*np.cos(theta2+theta3)
    dy = l2*np.sin(theta1)*np.cos(theta2) + l3*np.sin(theta1)*np.cos(theta2+theta3)
    dz = l1 + l2*np.sin(theta2) + l3*np.sin(theta2+theta3)
    print(dx,dy,dz)


if n==3:
    x = float(input("x: "))
    y = float(input("y: "))
    z = float(input("z: "))

    l1 = float(input("l1: "))
    l2 = float(input("l2: "))

    [theta1,theta2,d3] = scara_invkin(x,y,z,l1,l2)
    dx = l1*np.cos(theta1) + l2*np.cos(theta2+theta1)
    dy = l2*np.sin(theta1) + l2*np.sin(theta2+theta1)
    dz = -d3
    print(dx,dy,dz)
    
